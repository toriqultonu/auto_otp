package com.example.otp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.widget.EditText;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;

import androidx.annotation.RequiresApi;

public class OTPReceiver extends BroadcastReceiver {

    private static EditText editText_otp;

    public void setEditText_otp(EditText editText){
        OTPReceiver.editText_otp = editText;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        for (SmsMessage smsMessage : smsMessages) {

            // Get message timestamp in milliseconds
            long messageTimestamp = smsMessage.getTimestampMillis();

            // Convert to Date object if needed
            Date messageDate = new Date(messageTimestamp);

            // Format the date/time as needed
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String formattedTime = dateFormat.format(messageDate);

            // You can also get individual time components
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(messageTimestamp);

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1; // Month is 0-based
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            int second = calendar.get(Calendar.SECOND);

            System.out.println(year+" "+month+" "+day+" "+hour+" "+minute+" "+second);

            String message_body = smsMessage.getMessageBody();
            // Extract first 6 characters as they contain the OTP
            if (message_body != null && message_body.length() >= 6) {
                String getOTP = message_body.substring(0, 6);
                // Verify if the extracted string contains only digits
                if (getOTP.matches("\\d+")) {
                    editText_otp.setText(getOTP);
                }
            }
        }
    }
}